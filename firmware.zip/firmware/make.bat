@echo off
make.exe %*
